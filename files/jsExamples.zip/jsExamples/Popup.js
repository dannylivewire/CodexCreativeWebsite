"use strict";
var $Crate = $(Crate);
var Crate;
(function (Crate) {
    (function (Forms) {
        function Submit(event, form) {
            if(typeof form !== "undefined") {
                form.submit();
            } else if(typeof this.form !== "undefined") {
                this.form.submit();
            }
        }
        Forms.Submit = Submit;
        function SliceToLength(input, len) {
            if(input.value.length > len) {
                input.value = input.value.slice(0, len);
            }
        }
        Forms.SliceToLength = SliceToLength;
        function Validate(event, form) {
            if(typeof form !== "undefined") {
                form.validate();
                if(form.valid()) {
                    return true;
                }
            } else if(typeof this.form !== "undefined") {
                this.form.validate();
                if(this.form.valid()) {
                    return true;
                }
            }
            return false;
        }
        Forms.Validate = Validate;
        function BlockNonNumericInput(e) {
            var key = !e.charCode ? e.which : e.charCode;
            if(key > 57 || key < 48) {
                e.preventDefault();
            }
        }
        Forms.BlockNonNumericInput = BlockNonNumericInput;
        function ChangePostAction(form, url, targetObject) {
            var $targetForm = $(form);
            $targetForm.attr("action", url);
            $targetForm.attr("data-ajax-url", url);
            $targetForm.attr("data-ajax-update", $(targetObject).selector);
        }
        Forms.ChangePostAction = ChangePostAction;
        function showLoadingIcon() {
            $('.jsLoading').css('display', 'block');
        }
        Forms.showLoadingIcon = showLoadingIcon;
    })(Crate.Forms || (Crate.Forms = {}));
    var Forms = Crate.Forms;
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
    (function (DomLoad) {
        var ajaxTargetUpdateSuccessAction = "ajaxTargetUpdateSuccess";
        function init(selector) {
            if (typeof selector === "undefined") { selector = "body"; }
            BindEnterKey(selector);
            BindAjaxResponseValidationParsing(selector);
            BindAjaxResponseDrawers(selector);
            BindJsNumericTemp();
            $(document).ready(function () {
                $Crate.trigger("DomLoad", [
                    "body", 
                    null
                ]);
            });
        }
        DomLoad.init = init;
        function BindEnterKey(selector) {
            $(selector).on("keydown", "input", null, function (event) {
                if(event.which === 13) {
                    var $form = $(event.currentTarget).closest("form");
                    Crate.Forms.Submit(event, $form);
                }
            });
        }
        function BindAjaxResponseValidationParsing(selector) {
            $(selector).bind(ajaxTargetUpdateSuccessAction, function (event, target, response) {
                if($.validator && $.validator.unobtrusive && response && $(target).length > 0) {
                    $.validator.unobtrusive.parse($("form", response.target));
                }
                $Crate.trigger("DomLoad", [
                    target, 
                    response
                ]);
            });
        }
        function BindAjaxResponseDrawers(selector) {
            $(selector).bind(ajaxTargetUpdateSuccessAction, function (event, target, response) {
                if(Crate.UI && Crate.UI.Drawer) {
                    Crate.UI.Drawer.Init(target);
                }
            });
        }
        function BindJsNumericTemp() {
            $('input.jsNumeric').keydown(function (e) {
                var a = [
                    8, 
                    9, 
                    13, 
                    16, 
                    17, 
                    18, 
                    20, 
                    27, 
                    35, 
                    36, 
                    37, 
                    38, 
                    39, 
                    40, 
                    45, 
                    46, 
                    91, 
                    92
                ];
                var k = e.which;
                var i;
                for(i = 48; i < 58; i++) {
                    a.push(i);
                }
                for(i = 96; i < 106; i++) {
                    a.push(i);
                }
                if(!(a.indexOf(k) >= 0)) {
                    e.preventDefault();
                }
            });
        }
        DomLoad.BindJsNumericTemp = BindJsNumericTemp;
        init();
    })(Crate.DomLoad || (Crate.DomLoad = {}));
    var DomLoad = Crate.DomLoad;
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
    (function (UserUtilities) {
        try  {
            Crate.User = JSON.parse(sessionStorage.getItem('Crate.User'));
            $('body').trigger('UserDataUpdated');
        } catch (e) {
        }
        function LoadUserHandler() {
            LoadUser(Crate.Model && Crate.Model.Experiences ? Crate.Model.Experiences : []);
        }
        UserUtilities.LoadUserHandler = LoadUserHandler;
        function LoadUser(experiences) {
            if (typeof experiences === "undefined") { experiences = []; }
            var str = experiences.join(",");
            $.getScript(("/js/user_0.nocache?experiences=" + str).replace("0", (new Date()).toString().replace(/[^0-9]/g, "")));
        }
        $Crate.bind("ModelLoaded", function () {
            LoadUser(Crate.Model && Crate.Model.Experiences ? Crate.Model.Experiences : []);
        });
    })(Crate.UserUtilities || (Crate.UserUtilities = {}));
    var UserUtilities = Crate.UserUtilities;
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
    (function (Header) {
        function Init() {
            var $menulink = $('.menu-button');
            LoadHtml();
            $menulink.click(Click);
            $('body').bind('UserDataUpdated', LoadBasket);
            LoadBasket();
        }
        function LoadBasket() {
            if(Crate.User && Crate.User.BasketCount > 0) {
                $(".jsCountBasket").html(Crate.User.BasketCount.toString());
                $('.jsCartImage').removeClass('empty');
            } else {
                $(".jsCountBasket").html("0");
                $('.jsCartImage').addClass('empty');
            }
            $('.jsCartImage').removeClass('hide');
        }
        function LoadHtml() {
            var storage = window.sessionStorage;
            if(storage && storage.getItem("navHtml") != null) {
                var nav = storage.getItem("navHtml");
                LoadNavHtml(nav);
            } else {
                GetNavHtml();
            }
        }
        function GetNavHtml() {
            $.ajax({
                url: "/Browse/Home/GetNav",
                success: function (data) {
                    LoadNavHtml(data);
                    try  {
                        var storage = window.sessionStorage;
                        if(storage) {
                            storage.setItem("navHtml", data);
                        }
                    } catch (e) {
                    }
                },
                cache: false,
                async: false
            });
        }
        function LoadNavHtml(html) {
            var $menu = $('#menu');
            $menu.html(html);
            $menu.find(".jsHasChildren").click(SubNavClick);
        }
        function SubNavClick(event) {
            var container = $("#subContainer")[0];
            while(container.firstChild) {
                container.removeChild(container.firstChild);
            }
            var text = $(event.currentTarget).find("a").html();
            var node = $(event.currentTarget).find("ul")[0].cloneNode(true);
            $(node).removeClass("hide");
            container.appendChild(node);
            $("#subHeaderText").html(text);
            window.scrollTo(0, 0);
            $("#navContainer").css({
                marginLeft: "-100%"
            });
            $(node).find(".jsHasTerChildren").click(TerNavClick);
            event.preventDefault();
            return false;
        }
        function TerNavClick(event) {
            var container = $("#terContainer")[0];
            while(container.firstChild) {
                container.removeChild(container.firstChild);
            }
            var text = $(event.currentTarget).find("a").html();
            var node = $(event.currentTarget).find("ul")[0].cloneNode(true);
            $(node).removeClass("hide");
            container.appendChild(node);
            $("#terHeaderText").html(text);
            window.scrollTo(0, 0);
            $("#navContainer").css({
                marginLeft: "-200%"
            });
            event.preventDefault();
            return false;
        }
        function BackSubNavClick(event) {
            $("#navContainer").css({
                marginLeft: 0
            });
            event.preventDefault();
            return false;
        }
        Header.BackSubNavClick = BackSubNavClick;
        function BackTerNavClick(event) {
            $("#navContainer").css({
                marginLeft: "-100%"
            });
            event.preventDefault();
            return false;
        }
        Header.BackTerNavClick = BackTerNavClick;
        function Click(event) {
            var $body = $("body"), $bodyContainer = $("#bodyContainer"), $menu = $('#menu');
            if(/\bactive-nav\b/.test($body.attr("class"))) {
                $bodyContainer.height("100%");
                $body.removeClass("active-nav");
            } else {
                $body.addClass("active-nav");
                $bodyContainer.height($menu.height());
            }
            event.preventDefault();
            return false;
        }
        Init();
    })(Crate.Header || (Crate.Header = {}));
    var Header = Crate.Header;
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
    var Product;
    (function (Product) {
        $(".slider.single li").width($(".slider.single").width());
        var $window = $(window), flexslider;
        $window.resize(function () {
            var gridSize = getGridSize();
            if(flexslider && flexslider.vars) {
                flexslider.vars.minItems = gridSize;
                flexslider.vars.maxItems = gridSize;
            }
        });
        function applyFlexSlider() {
            $(".slider.single").flexslider({
                animation: "slide",
                animationLoop: false,
                directionNav: false,
                slideshow: false
            });
            $(".slider.single ul").removeClass("init-state");
            if($(".slider.single ul li").length <= 1) {
                $(".slider.single li").width("100%");
            }
            $(".slider.swatch").flexslider({
                animation: "slide",
                animationLoop: false,
                itemWidth: 58,
                controlNav: false,
                directionNav: false,
                slideshow: false
            });
            flexslider = $(".slider.multiple").flexslider({
                animation: "slide",
                animationLoop: false,
                itemWidth: 150,
                directionNav: false,
                slideshow: false,
                minItems: getGridSize(),
                maxItems: getGridSize()
            });
        }
        function getGridSize() {
            return (window.innerWidth < 300) ? 3 : (window.innerWidth < 600) ? 3 : 4;
        }
        $(applyFlexSlider);
    })(Product || (Product = {}));
    $('body').removeClass('no-js').addClass('js');
    $(window).load(function () {
        $("body").removeClass("preload");
    });
    (function (UI) {
        (function (Drawer) {
            function Init(selector) {
                if (typeof selector === "undefined") { selector = "body"; }
                var scope;
                if(selector && selector['currentTarget']) {
                    scope = $(selector['currentTarget']);
                } else if(selector) {
                    scope = $(selector);
                } else {
                    scope = $(document);
                }
                scope.find('.slide-btn').each(function (idx, elem) {
                    var $elem = $(elem);
                    if($elem.data("drawer-init") != "true") {
                        $elem.click(ClickHandler);
                        $elem.data("drawer-init", "true");
                    }
                });
            }
            Drawer.Init = Init;
            function ClickHandler(event) {
                Slide(event.currentTarget);
            }
            function Slide(element) {
                if (typeof element === "undefined") { element = this; }
                $(element).siblings('.slide-panel').toggle('fast');
                $(element).closest('.slide-btn').toggleClass('active');
                $(element).closest('.slide-open').toggleClass('active');
                Crate.Popup.ResizeBackground();
            }
            Drawer.Slide = Slide;
            function SlideCloseButton() {
                var element = $(this);
                element.parent('.slide-panel').hide();
                element.parent().closest('.slide-btn').toggleClass('active');
                element.parent().closest('.slide-open').toggleClass('active');
                Crate.Popup.ResizeBackground();
            }
            Drawer.SlideCloseButton = SlideCloseButton;
            function SlideClearThis() {
                var element = $(this);
                var count = parseFloat(element.closest('.jsNotifications').find('.jsCallout').html()) - 1;
                element.closest('.jsNotifications').find('.jsCallout').html(count.toString());
                if(count > 0) {
                    element.parent('.notification-message').remove();
                } else {
                    element.closest('.slide-panel').remove();
                }
                Crate.Popup.ResizeBackground();
            }
            Drawer.SlideClearThis = SlideClearThis;
            function SlideClearAll() {
                var element = $(this);
                element.siblings().remove();
                element.closest('.jsNotifications').find('.jsCallout').html("0");
                element.closest('.slide-panel').remove();
                element.remove();
                SlideCloseButton();
                Crate.Popup.ResizeBackground();
            }
            Drawer.SlideClearAll = SlideClearAll;
            Init();
        })(UI.Drawer || (UI.Drawer = {}));
        var Drawer = UI.Drawer;
    })(Crate.UI || (Crate.UI = {}));
    var UI = Crate.UI;
    var Button;
    (function (Button) {
        function Init() {
            $Crate.bind("DomLoad", DomLoadHandler);
        }
        function DomLoadHandler(event, selector) {
            $(".jsButtonDelay").each(function () {
                var buttonDelay = $(this);
                var buttonToggleState = setTimeout(function () {
                    buttonDelay.attr("href", buttonDelay.attr("data-href"));
                    buttonDelay.attr("data-action", "AddToCart");
                    buttonDelay.attr("data-href", "");
                    buttonDelay.html(buttonDelay.attr("data-text"));
                    buttonDelay.removeClass("btn-success").removeClass("jsButtonDelay").addClass("btn-primary");
                }, 3000);
            });
        }
        Init();
    })(Button || (Button = {}));
    var ErrorMessage;
    (function (ErrorMessage) {
        function Init() {
            $Crate.bind("DomLoad", DomLoadHandler);
        }
        function DomLoadHandler(event, selector) {
            $(document).ready(function () {
                if($(".jsAlert").length > 0) {
                    Crate.UI.Scroll.scrollTo($(".jsAlert"));
                }
            });
        }
        Init();
    })(ErrorMessage || (ErrorMessage = {}));
    var Tabs;
    (function (Tabs) {
        function Init() {
            $Crate.bind("DomLoad", DomLoadHandler);
        }
        function DomLoadHandler(selector) {
            if (typeof selector === "undefined") { selector = "body"; }
            var scope;
            if(selector && selector['currentTarget'] && Crate.isElement(selector['currentTarget'])) {
                scope = $(selector['currentTarget']);
            } else if(typeof selector === "string") {
                scope = $(selector);
            } else {
                scope = $(document);
            }
            scope.find('.jsTab').each(function () {
                var $active, $content, $links = $(this).find('a');
                $active = $($links.filter('[href="' + location.hash + '"]')[0] || $($links.filter(".selectedTab"))[0] || $links[0]);
                $active.addClass('active');
                $content = $($active.attr('href'));
                $links.not($active).each(function () {
                    $($(this).attr('href')).hide();
                });
                $(this).on('click', 'a', function (e) {
                    $active.removeClass('active');
                    $content.hide();
                    $active = $(this);
                    $content = $($(this).attr('href'));
                    $active.addClass('active');
                    $content.show();
                    e.preventDefault();
                });
            });
        }
        Init();
    })(Tabs || (Tabs = {}));
    (function (BreakPoints) {
        function IsMobile() {
            return $(".visible-xs").is(':visible');
        }
        BreakPoints.IsMobile = IsMobile;
    })(Crate.BreakPoints || (Crate.BreakPoints = {}));
    var BreakPoints = Crate.BreakPoints;
})(Crate || (Crate = {}));
$(document).ready(function () {
    $("body").bind("Account.RetrieveEmailAddress", Crate.Utilities.RetrieveEmailAddress);
});
var Crate;
(function (Crate) {
    (function (Utilities) {
        (function (String) {
            function startsWith(str, match) {
                if(match.length < str.length) {
                    return str.substr(0, match.length) == match;
                }
                return false;
            }
            function toArray(password) {
                var str;
                if(typeof password === "string") {
                    str = password;
                } else if(typeof password === "object") {
                    str = $(password).val();
                }
                var passArray = [];
                for(var i = 0, len = str.length; i < len; i++) {
                    passArray.push(str.charAt(i));
                }
                return passArray;
            }
        })(Utilities.String || (Utilities.String = {}));
        var String = Utilities.String;
        (function (Format) {
            function toDollars(num) {
                if(isNaN(num)) {
                    num = "0";
                }
                var sign = (num == (num = Math.abs(num)));
                num = Math.floor(num * 100 + 0.50000000001);
                var cents = num % 100;
                num = Math.floor(num / 100).toString();
                if(cents < 10) {
                    cents = "0" + cents;
                }
                for(var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
                    num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
                }
                return (((sign) ? '' : '-') + '$' + num + '.' + cents);
            }
            Format.toDollars = toDollars;
            function toPriceNoDollarSign(num) {
                if(isNaN(num)) {
                    num = "0";
                }
                var sign = (num == (num = Math.abs(num)));
                num = Math.floor(num * 100 + 0.50000000001);
                var cents = num % 100;
                num = Math.floor(num / 100).toString();
                if(cents < 10) {
                    cents = "0" + cents;
                }
                for(var i = 0; i < Math.floor((num.length - (1 + i)) / 3); i++) {
                    num = num.substring(0, num.length - (4 * i + 3)) + ',' + num.substring(num.length - (4 * i + 3));
                }
                return (num + '.' + cents);
            }
            Format.toPriceNoDollarSign = toPriceNoDollarSign;
            function toPercent(num) {
                var percent = num * 100;
                return percent;
            }
            Format.toPercent = toPercent;
            function toShortDate(jsonDate) {
                return this.dateToString(jsonDate.toDate());
            }
            Format.toShortDate = toShortDate;
            function dateToString(date) {
                date = new Date(date);
                return (date.getMonth() + 1) + "/" + date.getDate() + "/" + date.getFullYear();
            }
            Format.dateToString = dateToString;
            function fromShortDate(shortDateString) {
                var parsedArray = shortDateString.split("/");
                var month = parsedArray[0];
                var day = parsedArray[1];
                var year = parsedArray[2];
                var date = new Date(year, month - 1, day);
                date.setMinutes(date.getTimezoneOffset() * -1);
                return "/Date(" + date.getTime() + ")/";
            }
            Format.fromShortDate = fromShortDate;
        })(Utilities.Format || (Utilities.Format = {}));
        var Format = Utilities.Format;
        (function (Delegate) {
            function create(scope, method) {
                return function () {
                    return method.apply(scope, arguments);
                };
            }
            Delegate.create = create;
            function linkEvent(scope, method) {
                return function (event) {
                    if(event && event.preventDefault) {
                        event.preventDefault();
                    }
                    method.apply(scope, arguments);
                    return false;
                };
            }
            Delegate.linkEvent = linkEvent;
        })(Utilities.Delegate || (Utilities.Delegate = {}));
        var Delegate = Utilities.Delegate;
        (function (SessionStorage) {
            function isAvailable() {
                return typeof (window.sessionStorage) !== "undefined";
            }
            SessionStorage.isAvailable = isAvailable;
            function getItem(name) {
                try  {
                    if(typeof (window.sessionStorage) !== "undefined") {
                        return window.sessionStorage.getItem(name);
                    }
                } catch (e) {
                }
                return null;
            }
            SessionStorage.getItem = getItem;
            function setItem(name, value) {
                try  {
                    if(typeof (window.sessionStorage) !== "undefined") {
                        window.sessionStorage.setItem(name, value);
                        return true;
                    }
                } catch (e) {
                }
                return false;
            }
            SessionStorage.setItem = setItem;
            function removeItem(name) {
                try  {
                    if(typeof (window.sessionStorage) !== "undefined") {
                        window.sessionStorage.removeItem(name);
                        return true;
                    }
                } catch (e) {
                }
                return false;
            }
            SessionStorage.removeItem = removeItem;
        })(Utilities.SessionStorage || (Utilities.SessionStorage = {}));
        var SessionStorage = Utilities.SessionStorage;
        (function (Cookies) {
            function getCookie(name) {
                var start = document.cookie.indexOf(name + "=");
                var len = start + name.length + 1;
                if((!start) && (name != document.cookie.substring(0, name.length))) {
                    return null;
                }
                if(start == -1) {
                    return null;
                }
                var end = document.cookie.indexOf(';', len);
                if(end == -1) {
                    end = document.cookie.length;
                }
                return decodeURI(document.cookie.substring(len, end));
            }
            Cookies.getCookie = getCookie;
            function setCookie(name, value, exp_y, exp_m, exp_d, path, domain, secure) {
                var cookie_string = name + "=" + encodeURI(value);
                if(exp_y || exp_m || exp_d) {
                    var expires = new Date();
                    if(exp_y) {
                        expires.setFullYear(expires.getFullYear() + exp_y);
                    }
                    if(exp_m) {
                        expires.setMonth(expires.getMonth() + exp_m);
                    }
                    if(exp_d) {
                        expires.setDate(expires.getDate() + exp_d);
                    }
                    cookie_string += "; expires=" + expires.toUTCString();
                }
                if(path) {
                    cookie_string += "; path=" + encodeURI(path);
                } else {
                    cookie_string += "; path=/";
                }
                if(domain) {
                    cookie_string += "; domain=" + encodeURI(domain);
                }
                if(secure) {
                    cookie_string += "; secure";
                }
                document.cookie = cookie_string;
            }
            Cookies.setCookie = setCookie;
            function deleteCookie(name, path, domain) {
                if(this.getCookie(name)) {
                    var cookie_string = name + '=';
                    if(path) {
                        cookie_string += "; path=" + encodeURI(path);
                    } else {
                        cookie_string += "; path=/";
                    }
                    if(domain) {
                        cookie_string += "; domain=" + encodeURI(domain);
                    }
                    document.cookie = cookie_string + ';expires=Thu, 01-Jan-1970 00:00:01 GMT';
                }
            }
            Cookies.deleteCookie = deleteCookie;
        })(Utilities.Cookies || (Utilities.Cookies = {}));
        var Cookies = Utilities.Cookies;
        function RetrieveEmailAddress(event, args) {
            var emailAdddress = "";
            if(event.type == "Account") {
                emailAdddress = args.json.AjaxObject.UserName;
            } else if(event.type == "Checkout") {
                emailAdddress = args.json.AjaxObject.Email;
            }
        }
        Utilities.RetrieveEmailAddress = RetrieveEmailAddress;
    })(Crate.Utilities || (Crate.Utilities = {}));
    var Utilities = Crate.Utilities;
    (function (Display) {
        function initDisplayType(disp) {
        }
        Display.initDisplayType = initDisplayType;
    })(Crate.Display || (Crate.Display = {}));
    var Display = Crate.Display;
})(Crate || (Crate = {}));
var Provider;
(function (Provider) {
    var _geoCodeAPI = "http://maps.googleapis.com/maps/api/geocode/json?latlng={0}&sensor=true";
    var _defaultPostalCode = "";
    var GeolocationError = (function () {
        function GeolocationError(message, code) {
            this.message = message;
            this.code = code;
        }
        GeolocationError.prototype.toString = function () {
            return this.message;
        };
        return GeolocationError;
    })();    
    var PostalCodePosition = (function () {
        function PostalCodePosition(postalCode, position) {
            postalCode ? this.postalCode = postalCode : this.postalCode = _defaultPostalCode;
            if(position) {
                this.coords = position.coords;
            }
        }
        return PostalCodePosition;
    })();    
    function getPostalCodeFromGoogleGeoCode(data) {
        if(data && data.status == "OK" && data.results && data.results.length > 0) {
            for(var i = 0; i < data.results.length; i++) {
                var result = data.results[i];
                if(result && result.address_components && result.address_components.length > 0) {
                    for(var j = 0; j < result.address_components.length; j++) {
                        var components = result.address_components[j];
                        if(components && components.types && components.types.length) {
                            for(var k = 0; k < components.types.length; k++) {
                                var type = components.types[k];
                                if(type === "postal_code") {
                                    return components.short_name;
                                }
                            }
                        }
                    }
                }
            }
        }
        return null;
    }
    function geoPositionCallBack(position, positionSuccessCallback, getJson, positionErrorCallback) {
        if (typeof positionErrorCallback === "undefined") { positionErrorCallback = emptyStub; }
        if(!position) {
            positionErrorCallback(new GeolocationError("Geolocation API didn't return data.", Crate.GeolocationErrorCodes.POSITION_UNAVAILABLE), new PostalCodePosition());
            return;
        }
        var postalCodePosition = new PostalCodePosition(null, position);
        var url = _geoCodeAPI.replace("{0}", position.coords.latitude + "," + position.coords.longitude);
        var apiReturned = false;
        var timeout = false;
        window.setTimeout(function () {
            if(!apiReturned && positionErrorCallback) {
                timeout = true;
                positionErrorCallback(new GeolocationError("Geolocation API didn't return in a timely fashion.", Crate.GeolocationErrorCodes.TIMEOUT), postalCodePosition);
            }
        }, 5000);
        getJson(url, null, function (data) {
            if(timeout) {
                return;
            }
            apiReturned = true;
            if(!data) {
                positionErrorCallback(new GeolocationError("Geolocation API didn't return data.", Crate.GeolocationErrorCodes.GEOCODE_UNAVAILABLE), postalCodePosition);
                return;
            }
            var postalCode = getPostalCodeFromGoogleGeoCode(data);
            if(!postalCode || !/^\d{5}$/.test(postalCode)) {
                positionErrorCallback(new GeolocationError("Geolocation API returned data, but we were unable to locate a postal code.", Crate.GeolocationErrorCodes.POSTAL_CODE_UNAVAILABLE), postalCodePosition);
                return;
            }
            _defaultPostalCode = postalCode;
            postalCodePosition = new PostalCodePosition(postalCode, position);
            positionSuccessCallback(postalCodePosition);
        });
    }
    function errorGetCurrentPosition(positionErrorCallback, error) {
        positionErrorCallback(new GeolocationError(error.message, error.code), new PostalCodePosition());
    }
    function getFailbackPosition(error, postalCode) {
    }
    function emptyStub() {
    }
    var GeolocationProvider = (function () {
        function GeolocationProvider(geolocation, getJson, getCookie) {
            this._geolocation = geolocation;
            this._getJson = getJson;
            this._getCookie = getCookie;
            _defaultPostalCode = getCookie("zip");
        }
        GeolocationProvider.prototype.getCurrentLocation = function (successCallback, errorCallback) {
            var that = this;
            this._geolocation.getCurrentPosition(function (position) {
                geoPositionCallBack(position, successCallback, that._getJson, errorCallback);
            }, function (error) {
                errorGetCurrentPosition(errorCallback, error);
            });
        };
        GeolocationProvider.prototype.tryGetCurrentLocation = function (successCallback) {
            var failbackCallback = function (error, postalCode) {
                successCallback(postalCode);
            };
            this.getCurrentLocation(successCallback, failbackCallback);
        };
        return GeolocationProvider;
    })();
    Provider.GeolocationProvider = GeolocationProvider;    
})(Provider || (Provider = {}));
var Crate;
(function (Crate) {
    (function (GeolocationErrorCodes) {
        GeolocationErrorCodes._map = [];
        GeolocationErrorCodes.PERMISSION_DENIED = 1;
        GeolocationErrorCodes.POSITION_UNAVAILABLE = 2;
        GeolocationErrorCodes.TIMEOUT = 3;
        GeolocationErrorCodes.POSTAL_CODE_UNAVAILABLE = 4;
        GeolocationErrorCodes.GEOCODE_UNAVAILABLE = 5;
    })(Crate.GeolocationErrorCodes || (Crate.GeolocationErrorCodes = {}));
    var GeolocationErrorCodes = Crate.GeolocationErrorCodes;
        Crate.Geolocation = new Provider.GeolocationProvider(window.navigator.geolocation, $.getJSON, Crate.Utilities.Cookies.getCookie);
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
    (function ($) {
        $.belowthefold = function (element, settings) {
            var fold = $(window).height() + $(window).scrollTop();
            return fold <= $(element).offset().top - settings.threshold;
        };
        $.abovethetop = function (element, settings) {
            var top = $(window).scrollTop();
            return top >= $(element).offset().top + $(element).height() - settings.threshold;
        };
        $.rightofscreen = function (element, settings) {
            var fold = $(window).width() + $(window).scrollLeft();
            return fold <= $(element).offset().left - settings.threshold;
        };
        $.leftofscreen = function (element, settings) {
            var left = $(window).scrollLeft();
            return left >= $(element).offset().left + $(element).width() - settings.threshold;
        };
        $.inviewport = function (element, settings) {
            return !$.rightofscreen(element, settings) && !$.leftofscreen(element, settings) && !$.belowthefold(element, settings) && !$.abovethetop(element, settings);
        };
        $.extend($.expr[':'], {
            "below-the-fold": function (a, i, m) {
                return $.belowthefold(a, {
                    threshold: 0
                });
            },
            "above-the-top": function (a, i, m) {
                return $.abovethetop(a, {
                    threshold: 0
                });
            },
            "left-of-screen": function (a, i, m) {
                return $.leftofscreen(a, {
                    threshold: 0
                });
            },
            "right-of-screen": function (a, i, m) {
                return $.rightofscreen(a, {
                    threshold: 0
                });
            },
            "in-viewport": function (a, i, m) {
                return $.inviewport(a, {
                    threshold: 0
                });
            }
        });
    })(jQuery);
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
    Crate.Config;
    (function (Debug) {
        function trace(str) {
            if(Crate.Config.enableDebug === true) {
                str = String(str);
                window.console.log(str);
            }
        }
        Debug.trace = trace;
        function error(str) {
            if(Crate.Config.enableDebug === true) {
                str = String(str);
                window.console.error(str);
            }
        }
        Debug.error = error;
    })(Crate.Debug || (Crate.Debug = {}));
    var Debug = Crate.Debug;
    Crate.Model;
    (function (ErrorHandling) {
        var LogErrorUrl = "/LogError";
        function LogError(eventOrMessage, source, fileno) {
            if(eventOrMessage == null || eventOrMessage === "Script error.") {
                return;
            }
            if(LogErrorUrl == null) {
                window.alert('LogErrorUrl must be defined.');
                return;
            }
            var out = eventOrMessage;
            out += ": at document path '" + source + "'.";
            if(fileno != null) {
                out += "\n  at " + fileno;
            }
            $.ajax({
                type: 'POST',
                url: LogErrorUrl,
                data: {
                    message: out
                }
            });
        }
        ErrorHandling.LogError = LogError;
        window.onerror = LogError;
    })(Crate.ErrorHandling || (Crate.ErrorHandling = {}));
    var ErrorHandling = Crate.ErrorHandling;
    function isElement(element) {
        try  {
            return element instanceof HTMLElement;
        } catch (e) {
            var obj = (element);
            if(!obj) {
                return false;
            }
            return (typeof obj === "object") && (obj.nodeType === 1) && obj.style && (typeof obj.style === "object") && (typeof obj.ownerDocument === "object");
        }
    }
    Crate.isElement = isElement;
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
    (function (UI) {
        (function (Browser) {
            var _isIE6 = undefined;
            var _isNN = undefined;
            var _isMac = undefined;
            var _isChrome = undefined;
            var _isAndroid = undefined;
            var _isTouch = undefined;
            function classChaining() {
                return !isIE6();
            }
            Browser.classChaining = classChaining;
            function fixedPosition() {
                return !isIE6();
            }
            Browser.fixedPosition = fixedPosition;
            function isIE6() {
                if(_isIE6 === undefined) {
                    _isIE6 = /\bMSIE 6/.test(navigator.userAgent);
                }
                return _isIE6;
            }
            Browser.isIE6 = isIE6;
            function isNN() {
                if(_isNN === undefined) {
                    _isNN = (navigator.appName.indexOf("Netscape") != -1);
                }
                return _isNN;
            }
            Browser.isNN = isNN;
            function isMac() {
                if(_isMac === undefined) {
                    _isMac = (navigator.userAgent.toLowerCase().indexOf('mac') >= 0);
                }
                return _isMac;
            }
            Browser.isMac = isMac;
            function isChrome() {
                if(_isChrome === undefined) {
                    _isChrome = (navigator.userAgent.toLowerCase().indexOf('chrome') >= 0);
                }
                return _isChrome;
            }
            Browser.isChrome = isChrome;
            function isAndroid() {
                if(_isAndroid === undefined) {
                    _isAndroid = (/\bandroid\b/i.test(navigator.userAgent));
                }
                return _isAndroid;
            }
            Browser.isAndroid = isAndroid;
            function isTouch() {
                if(_isTouch === undefined) {
                    _isTouch = Modernizr.touch;
                }
                return _isTouch;
            }
            Browser.isTouch = isTouch;
        })(UI.Browser || (UI.Browser = {}));
        var Browser = UI.Browser;
    })(Crate.UI || (Crate.UI = {}));
    var UI = Crate.UI;
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
    (function (UI) {
        (function (Scroll) {
            function scrollTo(domObj, checkVisible, noAnimate) {
                var elemTop;
                if(isNaN(Number(domObj))) {
                    domObj = $(domObj);
                } else {
                    domObj = null;
                    checkVisible = false;
                    elemTop = Number(0);
                }
                var isPopup = false;
                var isDiv = true;
                var parent = $("#ajaxContent");
                if(parent.length <= 0) {
                    if(!Crate.UI.Browser.fixedPosition()) {
                        parent = $("#bodyWrap");
                    } else {
                        parent = $("html,body");
                        isDiv = false;
                    }
                } else {
                    isPopup = true;
                }
                var doScroll = !checkVisible || !domObj.is(":in-viewport");
                if(doScroll) {
                    if(domObj) {
                        elemTop = domObj.offset().top + (isDiv ? (parent.scrollTop() - parent.offset().top) : 0);
                    }
                    if(noAnimate || !Crate.UI.Browser.fixedPosition()) {
                        parent.scrollTop(elemTop);
                    } else {
                        parent.animate({
                            scrollTop: elemTop
                        }, 600);
                    }
                }
            }
            Scroll.scrollTo = scrollTo;
            function scrollTop(domObj, trackEvent) {
                scrollTo(domObj);
            }
            Scroll.scrollTop = scrollTop;
        })(UI.Scroll || (UI.Scroll = {}));
        var Scroll = UI.Scroll;
        function backToTop(noAnimate) {
            Crate.UI.Scroll.scrollTo(0, false, noAnimate);
        }
        UI.backToTop = backToTop;
        function scrollDown(event) {
            var scrollToAnchor = "#" + $(event.currentTarget).attr("title");
            Crate.UI.Scroll.scrollTo(scrollToAnchor);
        }
        UI.scrollDown = scrollDown;
        function getUpperRightCoors() {
            return {
                X: $(window).scrollLeft() + $(window).width(),
                Y: $(window).scrollTop()
            };
        }
        UI.getUpperRightCoors = getUpperRightCoors;
    })(Crate.UI || (Crate.UI = {}));
    var UI = Crate.UI;
})(Crate || (Crate = {}));
var Crate;
(function (Crate) {
    (function (Popup) {
        Popup.popupTarget = "#popupLayerTarget";
        var popupOpen = false;
        var pageLoadModel;
        $(document).ready(function () {
            pageLoadModel = Crate.Model;
            $(window).resize(PopupPosition);
        });
        function OpenSuccess(event, form, model) {
            if(history.pushState && !popupOpen) {
                var href = $(event.currentTarget).attr("href") || $(event.currentTarget).attr("data-ajax-url");
                history.pushState({
                    href: href,
                    isPopup: true,
                    model: model
                }, null, href);
                window.onpopstate = onPopState;
            }
            Crate.Model = model || pageLoadModel;
            $("body").addClass("active-popup");
            $(Crate).trigger("PopupLoad");
            popupOpen = true;
            PopupPosition();
        }
        Popup.OpenSuccess = OpenSuccess;
        function Close(target, form) {
            Reset();
            $("main[role='main']").removeClass("hide");
            history.back();
        }
        Popup.Close = Close;
        function onPopState(ev) {
            if(ev.state && ev.state.isPopup) {
                Crate.Model = ev.state.model || pageLoadModel;
                $("body").addClass("active-popup");
                $(Crate).trigger("PopupLoad");
            } else {
                Crate.Model = pageLoadModel;
                $("body").removeClass("active-popup");
                $(Crate).trigger("PopupClose");
                popupOpen = false;
            }
        }
        Popup.onPopState = onPopState;
        function PopupPosition(event, form, model) {
            if($("#body").hasClass("active-popup")) {
                if(Crate.BreakPoints.IsMobile()) {
                    Reset();
                    window.scrollTo(0, 0);
                    $("main[role='main']").addClass("hide");
                } else if($("html").width() > 752) {
                    $("main[role='main']").removeClass("hide");
                    var popupWidth = 700;
                    var popupOffset = 168;
                    var viewportWidth = $(window).width();
                    var pageHeight = $("body").height();
                    var scrollDistance = $(document).scrollTop();
                    var popUpHeight = $("aside[role='dialog']").height();
                    var popUpHorizontalPosition = (viewportWidth - popupWidth) / 2;
                    var backgroundHeight = popUpHeight + scrollDistance + popupOffset;
                    if(backgroundHeight > pageHeight) {
                        $(".dialog-background").height(backgroundHeight);
                    }
                    $("aside[role='dialog']").width(popupWidth);
                    if(popUpHorizontalPosition >= 0) {
                        $("aside[role='dialog']").offset({
                            top: (scrollDistance + (popupOffset / 2)),
                            left: popUpHorizontalPosition
                        });
                    } else {
                        $("aside[role='dialog']").offset({
                            top: (scrollDistance + (popupOffset / 2))
                        });
                    }
                    $(".dialog-background").click(function () {
                        Close();
                        console.log(".dialog-background click");
                    });
                }
            }
        }
        Popup.PopupPosition = PopupPosition;
        function ResizeBackground(event, form, model) {
            var popupOffset = 168;
            var scrollDistance = $(document).scrollTop();
            var popUpHeight = $("aside[role='dialog']").height();
            var pageHeight = $("body").height();
            var backgroundHeight = popUpHeight + scrollDistance + popupOffset;
            if(backgroundHeight > pageHeight) {
                $(".dialog-background").height(backgroundHeight);
            }
        }
        Popup.ResizeBackground = ResizeBackground;
        function Reset(event, form, model) {
            $(".dialog-background").css({
                "height": ""
            });
            $("aside[role='dialog']").css({
            });
            $("aside[role='dialog']").css({
                "width": "",
                "top": "auto",
                "left": "auto"
            });
        }
        Popup.Reset = Reset;
    })(Crate.Popup || (Crate.Popup = {}));
    var Popup = Crate.Popup;
})(Crate || (Crate = {}));
//@ sourceMappingURL=Popup.js.map
