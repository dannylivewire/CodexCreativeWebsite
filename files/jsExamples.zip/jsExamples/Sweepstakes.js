﻿var Crate = Crate || {};
Crate.Sweepstakes = {

    faqSearch: function (event, form) {
        var searchInput = form.find("input.jsSearchTerm");
        var searchVal = searchInput.val();

        // data("default") is set to the original text by Crate.UI.Toggle
        if (searchVal !== searchInput.data("default") && searchVal !== '') {
            window.location.href = "http://crateandbarrel.custhelp.com/cgi-bin/crateandbarrel.cfg/php/enduser/crate_results.php?p_search_text=" + searchVal;
        }
    },

    sweepsIndvEntry: function (event, form) {
        var validation = new Crate.Val.Form(Crate.Val.Form.CollectiveError, Crate.Val.Form.CollectiveSuccess);

        validation.register({ obj: "#txtFirstName", errorMsg: Crate.Messages.InvalidFirstName, onValidate: Crate.Val.$.IsValidText, domObj: $("#txtFirstName") });
        validation.register({ obj: "#txtLastName", errorMsg: Crate.Messages.InvalidLastName, onValidate: Crate.Val.$.IsValidText, domObj: $("#txtLastName") });
        validation.register({ obj: $("#txtEmail").val(), errorMsg: Crate.Messages.InvalidEmail, onValidate: Crate.Val.$.IsValidEmailAddress, domObj: $("#txtEmail") });

        if (!validation.validate())
            return;

        var request = new Crate.AJAX.Request('Giveaway|Request');
        request.FirstName = $("#txtFirstName").val();
        request.LastName = $("#txtLastName").val();
        request.Email = $("#txtEmail").val();
        request.RefererEmail = $("#hdnReferrerEmail").val();
        request.ContestName = $("#hdnContestName").val();

        request.submit(function (ajaxObject, json) {
            $("body").trigger("EmailSignupSuccess");

            //$("#SweepstakesEnterNow").addClass("hidden");
            //$("#SweepstakesIntroP").addClass("hidden");
            //$("#SweepstakesPrizesList").addClass("hidden");
            //$("#sweepsContest").addClass("hidden");

            //$("#sweepsSubmitShare").removeClass("hidden");
            //$("#ThankYouForEntryIntro").removeClass("hidden");
            //$("#SweepstakesEntered").removeClass("hidden");

            $(".jsNewEntry").addClass("hidden");
            $(".jsReferral").removeClass("hidden");
        });
    },

    sweepsIndvZipEntry: function (event, form) {
        // For Crate 30 Day Holiday Giveaway 2013

        var validation = new Crate.Val.Form(Crate.Val.Form.CollectiveError, Crate.Val.Form.CollectiveSuccess);

        validation.register({ obj: "#txtFirstName", errorMsg: Crate.Messages.InvalidFirstName, onValidate: Crate.Val.$.IsValidText, domObj: $("#txtFirstName") });
        validation.register({ obj: "#txtLastName", errorMsg: Crate.Messages.InvalidLastName, onValidate: Crate.Val.$.IsValidText, domObj: $("#txtLastName") });
        validation.register({ obj: $("#txtEmail").val(), errorMsg: Crate.Messages.InvalidEmail, onValidate: Crate.Val.$.IsValidEmailAddress, domObj: $("#txtEmail") });
        validation.register({ obj: $("#txtZip").val(), errorMsg: Crate.Messages.InvalidZip, onValidate: Crate.Val.$.IsValidZipCode, domObj: $("#txtZip") });

        if (!validation.validate())
            return;

        var request = new Crate.AJAX.Request('Giveaway|Request');
        request.FirstName = $("#txtFirstName").val();
        request.LastName = $("#txtLastName").val();
        request.Email = $("#txtEmail").val();
        request.ZIP = $("#txtZip").val();
        request.RefererEmail = $("#hdnReferrerEmail").val();
        request.ContestName = $("#hdnContestName").val();

        request.submit(function (ajaxObject, json)
        {
            $("body").trigger("EmailSignupSuccess");

            //$("#SweepstakesEnterNow").addClass("hidden");
            //$("#SweepstakesIntroP").addClass("hidden");
            //$("#SweepstakesPrizesList").addClass("hidden");
            //$("#sweepsContest").addClass("hidden");

            //$("#sweepsSubmitShare").removeClass("hidden");
            //$("#ThankYouForEntryIntro").removeClass("hidden");
            //$("#SweepstakesEntered").removeClass("hidden");

            $(".jsNewEntry").addClass("hidden");
            $(".jsReferral").removeClass("hidden");
        });
    },

    sweepsShare: function (event, form) {
        var validation = new Crate.Val.Form(Crate.Val.Form.CollectiveError, Crate.Val.Form.CollectiveSuccess);

        validation.register({ obj: $("#txtEmail1").val(), errorMsg: Crate.Messages.InvalidEmail, onValidate: Crate.Val.$.IsValidEmailAddress, domObj: $("#txtEmail1"), required: $("#lblEmail1 span.required").length > 0 });
        validation.register({ obj: $("#txtEmail2").val(), errorMsg: Crate.Messages.InvalidEmail, onValidate: Crate.Val.$.IsValidEmailAddress, domObj: $("#txtEmail2"), required: $("#lblEmail2 span.required").length > 0 });
        validation.register({ obj: $("#txtEmail3").val(), errorMsg: Crate.Messages.InvalidEmail, onValidate: Crate.Val.$.IsValidEmailAddress, domObj: $("#txtEmail3"), required: $("#lblEmail3 span.required").length > 0 });
        validation.register({ obj: $("#txtEmail4").val(), errorMsg: Crate.Messages.InvalidEmail, onValidate: Crate.Val.$.IsValidEmailAddress, domObj: $("#txtEmail4"), required: $("#lblEmail4 span.required").length > 0 });
        validation.register({ obj: $("#txtEmail5").val(), errorMsg: Crate.Messages.InvalidEmail, onValidate: Crate.Val.$.IsValidEmailAddress, domObj: $("#txtEmail5"), required: $("#lblEmail5 span.required").length > 0 });

        if (!validation.validate())
            return;

        var recipientList = $("#txtEmail1").val();
        if ($("#txtEmail2").val().length > 0) {
            recipientList += ";";
            recipientList += $("#txtEmail2").val();
        }
        if ($("#txtEmail3").val().length > 0) {
            recipientList += ";";
            recipientList += $("#txtEmail3").val();
        }
        if ($("#txtEmail4").val().length > 0) {
            recipientList += ";";
            recipientList += $("#txtEmail4").val();
        }
        if ($("#txtEmail5").val().length > 0) {
            recipientList += ";";
            recipientList += $("#txtEmail5").val();
        }


        var request = new Crate.AJAX.Request('SweepsShare|Request');
        request.ShareEmails = recipientList;
        request.FirstName = $("#txtFirstName").val();
        request.LastName = $("#txtLastName").val();
        request.Email = $("#txtEmail").val();

        request.submit(function (ajaxObject, json) {
            //$("#SweepstakesEntered").addClass("hidden");
            //$("#ThankYouForEntryIntro").addClass("hidden");
            //$("#SweepstakesEntered").addClass("hidden");

            //$("#ThankYouForSharingIntro").removeClass("hidden");
            //$("#SweepstakesSocialLinks").removeClass("hidden");
            $(".jsReferral").addClass("hidden");
            $(".jsSocial").removeClass("hidden");
        });
    },

    close: function () {
        Crate.UI.Drawer.close('.jsDrawerContent');
    }
};
