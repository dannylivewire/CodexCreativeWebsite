/// <reference path="UI/Scroll.ts" />
/// <reference path="../jQuery/jquery.d.ts" />

module Crate {
    export module Popup {
        export var popupTarget = "#popupLayerTarget";
        var popupOpen = false;
        var pageLoadModel;
        $(document).ready(function () {
            pageLoadModel = Crate.Model;
            $(window).resize(PopupPosition);
        });
        export function OpenSuccess(event: JQueryEventObject, form: JQuery, model: any) {
            if (history.pushState && !popupOpen) {
                var href = $(event.currentTarget).attr("href") || $(event.currentTarget).attr("data-ajax-url");
                history.pushState({ href: href, isPopup: true, model: model }, null, href);
                window.onpopstate = onPopState;
            }
            Crate.Model = model || pageLoadModel;
            $("body").addClass("active-popup");
            $(Crate).trigger("PopupLoad");
            popupOpen = true;
            PopupPosition();
        }
        export function Close(target: JQueryEventObject, form: JQuery) {
            Reset();
            $("main[role='main']").removeClass("hide");
            history.back(); /* this will need to be refactored. It doesn't work correctly if I open the same popup twice. We also do not want to use new URLs for popUps.*/
        }
        export function onPopState(ev: PopStateEvent) {
            if (ev.state && ev.state.isPopup) {
                Crate.Model = ev.state.model || pageLoadModel;
                $("body").addClass("active-popup");
                $(Crate).trigger("PopupLoad");
            } else {
                Crate.Model = pageLoadModel;
                $("body").removeClass("active-popup");
                $(Crate).trigger("PopupClose");
                popupOpen = false;
            }
        }
        export function PopupPosition(event: JQueryEventObject, form: JQuery, model: any) {
            if ($("#body").hasClass("active-popup")) {
                if (Crate.BreakPoints.IsMobile()) { //We need to check and see if the viewport is above the tablet breakpoint on resize.
                    Reset();
                    window.scrollTo(0, 0); //scroll back to the top
                    $("main[role='main']").addClass("hide");
                }
                else if($("html").width() > 752) { //We need to check and see if the viewport is above the tablet breakpoint on resize.
                    $("main[role='main']").removeClass("hide");

                    var popupWidth = 700;
                    var popupOffset = 168;
                    var viewportWidth = $(window).width();
                    var pageHeight = $("body").height();
                    var scrollDistance = $(document).scrollTop();
                    var popUpHeight = $("aside[role='dialog']").height();
                    var popUpHorizontalPosition = (viewportWidth - popupWidth) / 2;
                    var backgroundHeight = popUpHeight + scrollDistance + popupOffset;

                    if (backgroundHeight > pageHeight) {
                        $(".dialog-background").height(backgroundHeight); //is pop up bigger than page height, adjust the background height
                    }
                    $("aside[role='dialog']").width(popupWidth); //assign width of pop up

                    if (popUpHorizontalPosition >= 0)
                        $("aside[role='dialog']").offset({ top: (scrollDistance + (popupOffset / 2)), left: popUpHorizontalPosition }); //assign position of popup from top of page
                    else
                        $("aside[role='dialog']").offset({ top: (scrollDistance + (popupOffset / 2)) }); //assign position of popup from top of page

                    $(".dialog-background").click(function () {
                        Close();
                        console.log(".dialog-background click");
                    });
                }
            }
        }
        export function ResizeBackground(event: JQueryEventObject, form: JQuery, model: any) {
            var popupOffset = 168;
            var scrollDistance = $(document).scrollTop();
            var popUpHeight = $("aside[role='dialog']").height();
            var pageHeight = $("body").height();
            var backgroundHeight = popUpHeight + scrollDistance + popupOffset;

            if (backgroundHeight > pageHeight) {
                $(".dialog-background").height(backgroundHeight); //is pop up bigger than page height, adjust the background height
            }
        }
        export function Reset(event: JQueryEventObject, form: JQuery, model: any) {
            $(".dialog-background").css({ "height": "" });
            $("aside[role='dialog']").css({});
            $("aside[role='dialog']").css({
                "width": "",
                "top": "auto",
                "left": "auto"
            });
        }
    }
}