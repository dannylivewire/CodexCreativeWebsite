Example Summary:

1) footer.js - Crate and Barrel - for basic elements in the footer, I wrote this when redesigning the global elements. Used to load FB social like button in the footer when the user scrolls below the fold.

2) Carousel.js - Crate and Barrel, CB2, LON - this activates the jCarousel class (separate) to customize it for CB, it was then further styled with different CSS per brand.

3) Sweepstakes.js - Crate and Barrel - used to manage sweepstakes entries

4) Popup.js & Popup.ts - Crate and Barrel, CB2, LON - an example of TypeScript that compiles into JS, used cross-brand to control how our Popups work at both mobile size, and desktop sized. Visit - http://m.cb2.com/Checkout/Cart/ - and click "checkout faqs" to see it in action. You can also visit - http://m.landofnod.com/Checkout/Cart/ - and - http://m.crateandbarrel.com/Checkout/Cart/ for the other branded versions. (Special note: the rest of the site other than /Checkout/ is not fully responsive finished yet, just my section - Checkout is, make these pages small width to see it in action!)

5) common_admin.js - WMS Gaming - custom JS used to track users and do dynamic state changes.

6) DYI_lightbox.html - Fun one! - I did this on my own as an example to a friend to show the appeal of vanilla JS. It basically emulates a "lightbox / popup" functionality, but does so with only 2 functions, containing 2 lines of real JavaScript. No jQuery, nothing fancy.
