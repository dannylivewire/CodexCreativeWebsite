var center;
var overlay;
var slideWidth = 740;
var currPlayer = null;
var players = new Array();

function onYouTubePlayerReady(playerId) {
  ytplayer = document.getElementById("myytplayer");
  ytplayer.addEventListener("onStateChange", "onytplayerStateChange");
}

function onytplayerStateChange(newState) {
   alert("Player's new state: " + newState);
}

function wmsTracking(obj){
	
	//var prop1 = obj.prop1;
	//var prop2 = obj.prop2;
	//var evt	= obj.evt;
	
	//alert(obj.evt);
	
	$.post('/tracking/wmsTracking/',
	      obj,

	      function(result) {
		
	        if (result) {
				//do nothing
	        }
	
	      }
	    );
}

function openVid(id, vidId, vidName){
			
	currOverlay = id;
		
	initScrim();
	
	var windowHeight = $(window).height(); 
	var windowWidth = $(window).width();
		
	$('#' + id).css('opacity', 0);
	
	var overlayWidth = $('#' + id).width();
	var overlayHeight = $('#' + id).height();
	
	var xPos = (windowWidth - overlayWidth) / 2;
	var yPos = ((windowHeight - overlayHeight) / 2) + $(window).scrollTop();

	if(yPos < 10){
		yPos = 50;
	}
	
	$('#' + id).css('visibility', 'visible');
	$('#' + id).css('display', 'block');
					
	$('#' + id).css('left', xPos + 'px');
	$('#' + id).css('top', yPos + 'px');
	
	Elastic.refresh(document.getElementById(id));
									
	$('#overlayScrim').animate({opacity:0.8}, 200);
	$('#' + id).animate({opacity:1}, 200);
	
	jwplayer(vidId).play(true);
	
	//wmsTracking({evt:'video', prop1:vidName});
		
}

function login(){
		
	email = $('#emailField').val();
	pin = $('#pinField').val();
			
	$.post('/admin/ajaxLogin/',{ 'email':email, 'pass':pin },

	      function(result) {
		
	        if (result == 'true') {
				closeOverlay();
				location.reload(true);
	        }
			else{
				$('#login .error').html('You have entered an incorrect email or PIN.  Please try again.')
			}
	
	      }
	
	    );
}

function resetPin(){
	email = $('#resetEmail').val();
					
	$.post('/admin/doReset/',{ 'email':email },

	      function(result) {
		
	        if (result == 'true') {
				openOverlay('pinSent', false);
	        }
			else{
				$('#forgotPin .error').html('That email is not registered in the system. Is this the email address that you typically use for work purposes? Please try again.')
			}
	
	      }
	
	    );
}

function changePin(){
	//alert("change pin");
	var newPin = $('#newPin').val();
	var newPinConf = $('#newPinConf').val();
	
	if(newPin != newPinConf){
		$('#changePin .error').html('The PINS do not match.  Please try again.');
	}else{
		//alert(email);
		$.post('/admin/doNewPin/',{ 'newPin':newPin},
				
		      function(result) {
					//alert(result);
		        if (result == 'true') {
					//alert("result true");
					openOverlay('newPinSent', false);
		        }else if(result=='nonnumeric'){
					$('#changePin .error').html('Your PIN must only contain numbers');
				}else{
					//alert("result false");
					$('#changePin .error').html('That email is not registered in the system. Is this the email address that you typically use for work purposes? Please try again or click <a href="javascript:void(0);" onclick="openOverlay(\'requestAccount\', false);">here</a> to request access.');
				}

		      }

		    );
	}
					
}


function initScrim(){
	var windowHeight = $(document).height(); 
	var windowWidth = $(window).width(); 
	$('#overlayScrim').css({'opacity':'0','visibility':'visible','display':'block'});
	$('#overlayScrim').css({ 'width':windowWidth,'top': '0','height':windowHeight, 'left':0});
}

function showShareOverlay(){	
	//$('#shareOverlay').css('opacity',0);
	$('#shareOverlay').css('visibility','visible');
	//$('#shareOverlay').animate({opacity:1}, 200);
	
	var windowHeight = $(document).height(); 
	var windowWidth = $(window).width(); 
	$('#shareScrim').css({'opacity':'0','visibility':'visible','display':'block'});
	$('#shareScrim').css({ 'width':windowWidth,'top': '0','height':windowHeight, 'left':0});
}

function hideShareOverlay(){
	//$('#shareOverlay').css('opacity',0);
	$('#shareOverlay').css('visibility','hidden');
	$('#shareScrim').css('visibility','hidden');	
}

function showNavProds(){
	$('#navProdOverlay').css('visibility', 'visible');
	$('#navProdOverlay').css('opacity', '1');
	$('#firstNavTab').css('visibility', 'visible');
	showNavScrim();
}

function hideNavProds(){
	$('#navProdOverlay').css('visibility', 'hidden');
	$('#navProdOverlay').css('opacity', '0');
	$('#firstNavTab').css('visibility', 'hidden');
	$('#navScrim').css({'opacity':'0','visibility':'hidden','display':'none'});
}

function showNavScrim(){
	var windowHeight = $(window).height(); 
	var windowWidth = $(window).width(); 
	$('#navScrim').css({'opacity':'0','visibility':'visible','display':'block'});
	$('#navScrim').css({ 'width':windowWidth,'top': '0','height':windowHeight, 'opacity':'0' });
}

function openOverlay(id, animateScrim){
	
	currOverlay = 'overlay';
	
	try{
	ytswf.stopVideo();
	}catch(e){}
	
	if(animateScrim != false){
		initScrim();
	}
	
	var windowHeight = $(window).height(); 
	var windowWidth = $(window).width();
	
	var contentWidth = $('#' + id).width();
	
	$('#overlayContent').empty();
					
	$('#' + id).clone().appendTo('#overlayContent');
	
	$('#overlayContent .error').html('');
									
	$('#overlayContent div').css('visibility', 'visible');
	$('#overlayContent div').css('display', 'block');
	
	$('#overlay').css('width', (contentWidth + 60) + 'px');
	Elastic.refresh(document.getElementById('overlay'));
	
	$('#overlay').css('opacity', 0);
	$('#overlay').css('visibility', 'visible');
	
	var overlayWidth = $('#overlay').width();
	var overlayHeight = $('#overlay').height();
	
	var xPos = (windowWidth - overlayWidth) / 2;
	var yPos = ((windowHeight - overlayHeight) / 2) + $(window).scrollTop();

	if(yPos < 10){
		yPos = 50;
	}
					
	$('#overlay').css('left', xPos + 'px');
	$('#overlay').css('top', yPos + 'px');
	
	if(animateScrim != false){								
		$('#overlayScrim').animate({opacity:0.8}, 200);
	}
	$('#overlay').animate({opacity:1}, 200);
					
}

function closeOverlay(){
	
	try{
		jwplayer(currPlayer).stop();
		currPlayer = null;
	}
	catch(e){}
	
	$('#overlayScrim').css('visibility', 'hidden');
	$('#' + currOverlay).css('visibility', 'hidden');
	$('#overlayContent').empty();
	$('#ytapiplayer').css('visibility', 'visible');
	$('#ytapiplayer').css('opacity', 1);
	$('#ytapiplayer').css('display', 'block');
}

$(window).load(function(){
		
	var slideshowPos = $('#slideshow').offset();
	var shareLinkPos = $('#shareLink').offset();
		
	try{
				
		$('#leftControl').css('top', slideshowPos.top + 55);
		$('#leftControl').css('left', slideshowPos.left);
		$('#leftControl').css('visibility', 'visible');
		
		$('#rightControl').css('top', slideshowPos.top + 55);
		$('#rightControl').css('left', slideshowPos.left + slideWidth - 42);
		$('#rightControl').css('visibility', 'visible');
		
	}
	catch(e){
		
	}
	
	try{
		$('#shareOverlay').css('top', shareLinkPos.top + 0);
		$('#shareOverlay').css('left', shareLinkPos.left - 132);
	}
	catch(e){
		
	}
	
	try{
		$('.overlays').css('display', 'none');
	}
	catch(e){}
		
});

$(window).resize(function() {
	
	var slideshowPos = $('#slideshow').offset();
	var shareLinkPos = $('#shareLink').offset();
	
	try{
		
		$('#leftControl').css('top', slideshowPos.top + 55);
		$('#leftControl').css('left', slideshowPos.left);
		$('#leftControl').css('visibility', 'visible');
		
		$('#rightControl').css('top', slideshowPos.top + 55);
		$('#rightControl').css('left', slideshowPos.left + slideWidth - 42);
		$('#rightControl').css('visibility', 'visible');
		
	}
	catch(e){
		
	}
	
	try{
		$('#shareOverlay').css('top', shareLinkPos.top + 0);
		$('#shareOverlay').css('left', shareLinkPos.left - 132);
	}
	catch(e){
		
	}
	
	try{
		var windowHeight = $(document).height(); 
		var windowWidth = $(window).width(); 
		$('#overlayScrim').css({ 'width':windowWidth,'top': '0','height':windowHeight, 'left':0});
		
		var overlayWidth = $('#overlay').width();
		var overlayHeight = $('#overlay').height();

		var xPos = (windowWidth - overlayWidth) / 2;
		var yPos = ((windowHeight - overlayHeight) / 2) + $(window).scrollTop();

		if(yPos < 10){
			yPos = 50;
		}

		$('#overlay').css('left', xPos + 'px');
		//$('#overlay').css('top', yPos + 'px');
		
		
	}
	catch(e){}
	
});

$(document).ready(function(){
		
	$('#overlayScrim').click(function() {
	  closeOverlay();
	});
	
	
	$('#navScrim').mouseover(function() {
	  hideNavProds();
	});
	
	$('#shareScrim').mouseover(function() {
	  hideShareOverlay();
	});
		
	
	
  var currentPosition = 0;  
  var slides = $('.slide');
  var numberOfSlides = slides.length;

  // Remove scrollbar in JS
  $('#slidesContainer').css('overflow', 'hidden');

  // Wrap all .slides with #slideInner div
  slides
    .wrapAll('<div id="slideInner"></div>')
    // Float left to display horizontally, readjust .slides width
	.css({
      'float' : 'left',
      'width' : slideWidth
    });

  // Set #slideInner width equal to total width of all slides
  $('#slideInner').css('width', slideWidth * numberOfSlides);

  // Insert controls in the DOM
  //$('#slideshow')
   // .prepend('<span class="control" id=""></span>')
   // .append('<span class="control" id=""></span>');

  // Hide left arrow control on first load
  manageControls(currentPosition);

  // Create event listeners for .controls clicks
  $('.control')
    .bind('click', function(){
    // Determine new position
	currentPosition = ($(this).attr('id')=='rightControl') ? currentPosition+1 : currentPosition-1;
    
	// Hide / show controls
    manageControls(currentPosition);
    // Move slideInner using margin-left
    $('#slideInner').animate({
      'marginLeft' : slideWidth*(-currentPosition)
    });
  });

  // manageControls: Hides and Shows controls depending on currentPosition
  function manageControls(position){
    // Hide left arrow if position is first slide
	if(position==0){ $('#leftControl').hide() } else{ $('#leftControl').show() }
	// Hide right arrow if position is last slide
    if(position==numberOfSlides-1){ $('#rightControl').hide() } else{ $('#rightControl').show() }
  }

	//overlay handler
	$('#navProdOverlay').css('visibility', 'hidden');
	$('#firstNavTab').css('visibility', 'hidden');
	
	try{
		$('a[title]').tooltip({showURL: false});
	}
	catch(e){}
		
});