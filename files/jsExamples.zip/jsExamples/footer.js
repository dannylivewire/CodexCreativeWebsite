﻿$(function () {

    $("body").bind("UserDataUpdated", loadStoreFooter);

    if (Crate.User) { loadStoreFooter(); }

    function loadStoreFooter() {
        if ($('#storeTemplate').length > 0 && $('#storeHolder').length > 0) {
            var cartHtml = $('#storeTemplate').render(Crate.User || {});
            $("#storeHolder").html(cartHtml);
        }
    }

    function processScroll() {
        if (!$.belowthefold(fbLike, settings)) {
            if ($('#fb-like iframe').length < 1) {
                fbLike.append(
                    $("<iframe />").attr({
                        src: document.location.protocol + "//www.facebook.com/plugins/like.php?href=http%3A%2F%2Fwww.facebook.com%2Fcrateandbarrel&layout=button_count&show_faces=false&width=150&action=like&font=arial&colorscheme=light&height=21",
                        scrolling: "no",
                        frameborder: "0",
                        style: "border:none; overflow:hidden; width:115px; height:21px;",
                        allowTransparency: "true"
                    })
                );
                $win.unbind("scroll", processScroll);
            }
        }
    }

    var $win = $(window),
    settings = {
        threshold: 0
    },
    fbLike = $("#fb-like");
    if (fbLike.length > 0) {
        processScroll();
        $win.bind("scroll", processScroll);
    }
});
