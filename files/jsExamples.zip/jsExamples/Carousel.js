var Crate = Crate || {};

Crate.Carousel = {

    init: function (numberVisible, scrollStep, startIndex, selector, wrapValue, initCallbackValue, autoCarousel, animationSpeed, itemLastInCallbackValue, itemLoadCallbackValue, animationStepCallbackValue) {
        numberVisible = numberVisible || 3;
        scrollStep = scrollStep || numberVisible;
        startIndex = startIndex || 1;
        wrapValue = wrapValue || null;
        initCallbackValue = initCallbackValue || null;
        autoCarousel = autoCarousel || 0;
        animationSpeed = animationSpeed || 1000;
        itemLastInCallbackValue = itemLastInCallbackValue || null;
        itemLoadCallbackValue = itemLoadCallbackValue || null;
        animationStepCallbackValue = animationStepCallbackValue || null;

        var $carousel = $(selector || "#carousel");
        var childCount = $carousel.children().length;
        if (childCount > numberVisible) {
            var jcarousel = $carousel.jcarousel({
                size: childCount,
                visible: numberVisible,
                scroll: scrollStep,
                start: startIndex,
                wrap: wrapValue,
                initCallback: initCallbackValue,
                auto: autoCarousel,
                animation: animationSpeed,
                itemLastInCallback: itemLastInCallbackValue,
                itemLoadCallback: itemLoadCallbackValue,
                animationStepCallback: animationStepCallbackValue
            }).data('jcarousel');
            $carousel.swipe({
                left: function (e) {
                    jcarousel.funcNext();
                },
                right: function (e) {
                    jcarousel.funcPrev();
                }
            });
            return jcarousel;
        } else {
            return null;
        }
    },

    replaceCarouselArrows: function (carousel) {
        $(".jcarousel-next").html("<span class=\"outer\"></span><span class=\"inner\"></span>");
        $(".jcarousel-prev").html("<span class=\"outer\"></span><span class=\"inner\"></span>");
    }

};
